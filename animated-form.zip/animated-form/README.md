# animated form

A Pen created on CodePen.io. Original URL: [https://codepen.io/technext/pen/WNpWeWw](https://codepen.io/technext/pen/WNpWeWw).

